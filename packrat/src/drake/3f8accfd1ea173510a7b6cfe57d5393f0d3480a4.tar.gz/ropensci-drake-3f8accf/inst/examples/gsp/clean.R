drake::clean(destroy = TRUE)
unlink(c("report.html", "figure"), recursive = TRUE)
