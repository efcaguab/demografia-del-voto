This example demonstrates how to deploy targets to separate
jobs on a [Docker container](https://www.docker.com/what-container) using `"future_lapply"` parallelism and a specialized PSOCK cluster.
When you are ready, run `run.R` to run the example.
